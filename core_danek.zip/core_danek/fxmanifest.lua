fx_version 'cerulean'
lua54 "yes"

game 'gta5'

client_scripts {
    'client/**/*.lua',
}

server_scripts {
    '@mysql-async/lib/MySQL.lua',
    'server/**/*.lua',
}

shared_scripts {
    '@es_extended/imports.lua',
    'shared/**/*.lua',
    '@ox_lib/init.lua'
}
local tiers = {
    ['none'] = {
        Index = 0,
        Label = 'Žádné',
        ChatColor = '',
        Respawn = 7 * 60000,
        Hospital = 3 * 60000,
        BrigadeMultiplier = 1.0,
        DrugSellMultiplier = 1.0,
        Daily = {
            {
                Type = 'item',
                Name = 'ammo-9',
                Count = 30
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 1000
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 2000
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 3000
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 4000
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 5000
            },
        }
    },
    ['bronze'] = {
        Index = 1,
        Label = 'Bronze',
        ChatColor = 'background: linear-gradient(to right, #ca8c73, #FFA672, #ca8c73); -webkit-background-clip: text; -webkit-text-fill-color: transparent; text-shadow: 0 0 5px #de9a80, 0 0 10px #de9a80;',
        Respawn = 5 * 60000,
        Hospital = 2 * 60000,
        BrigadeMultiplier = 1.25,
        DrugSellMultiplier = 1.25,
        Instant = {
            {
                Type = 'account',
                Name = 'ds_coin',
                Count = 200
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 50000
            }
        },
        Daily = {
            {
                Type = 'account',
                Name = 'money',
                Count = 3000
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 4000
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 5000
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 6000
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 7000
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 7500
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 10000
            },
        }
    },
    ['silver'] = {
        Index = 2,
        Label = 'Silver',
        ChatColor = 'background: linear-gradient(to right, #a0a0a0, #e6e6e6, #f0f0f0, #e6e6e6, #a0a0a0);-webkit-background-clip: text;-webkit-text-fill-color: transparent;text-shadow: 0 0 10px #dadada, 0 0 15px #e0e0e0;',
        Respawn = 4 * 60000,
        Hospital = 1 * 60000,
        BrigadeMultiplier = 1.5,
        DrugSellMultiplier = 1.5,
        Instant = {
            {
                Type = 'account',
                Name = 'ds_coin',
                Count = 500
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 100000
            },
        },
        Daily = {
            {
                Type = 'vehicle',
                Hash = 'bf400',
                Label = 'BF400'
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 5000
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 6000
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 7000
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 7500
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 10000
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 15000
            },
        }
    },
    ['gold'] = {
        Index = 3,
        Label = 'Gold',
        ChatColor = 'background: linear-gradient(to right, #ffd700, #ffec8b, #fffacd, #ffec8b, #ffd700);-webkit-background-clip: text;-webkit-text-fill-color: transparent;text-shadow: 0 0 10px #ffd700, 0 0 10px #ffd700, 0 0 15px #ffd700;',
        Respawn = 3 * 60000,
        Hospital = 0.5 * 60000,
        BrigadeMultiplier = 1.75,
        DrugSellMultiplier = 1.75,
        Instant = {
            {
                Type = 'account',
                Name = 'ds_coin',
                Count = 1000
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 250000
            },
            {
                Type = 'vehicle',
                Hash = 'bf400',
                Label = 'BF400'
            }
        },
        Daily = {
            {
                Type = 'vehicle',
                Hash = 'bf400',
                Label = 'BF400'
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 7500
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 10000
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 15000
            },
            {
                Type = 'account',
                Name = 'money',
                Count = 25000
            },
        }
    },
}

local groups = {
    ['admin'] = true
}

local players = {}

math.randomseed(os.time())

local charset = {}  do -- [0-9,A-Z]
    for c = 48, 57  do table.insert(charset, string.char(c)) end
    for c = 65, 90  do table.insert(charset, string.char(c)) end
end

function GetTableSize(t)
    local count = 0

	for _,_ in pairs(t) do
		count = count + 1
	end

	return count
end

function GetRandomString(length)
    if not length or length <= 0 then
        return '' 
    end
    return GetRandomString(length - 1) .. charset[math.random(1, #charset)]
end

function GetIdentifier(player, identifierType)
    local identifiers = GetPlayerIdentifiers(player)
    for k,v in pairs(identifiers) do
        if string.find(v, identifierType) then
            return v
        end
    end
end

RegisterCommand('generatevip', function(source, args, raw)
    local tier = raw:sub(13)
    local xPlayer = ESX.GetPlayerFromId(source)
    if groups[xPlayer.getGroup()] then
        if tiers[tier] ~= nil then
            local code = GetRandomString(25)
            print('Kód: ' .. code)
            MySQL.insert.await('INSERT INTO vip_codes (code, tier) VALUES (?, ?)', { code, tier })
            print('Kód: ' .. code)
            return
        else
            TriggerClientEvent('core:showNotification', source, 'Neplatné VIP.', 'error')
        end
    end
end)

local cooldown = {}
local checked = {}

RegisterCommand('redeem', function(source, args, raw)
    if cooldown[source] == nil then
        local code = raw:sub(8)
        cooldown[source] = true
        Citizen.SetTimeout(10000, function()
            cooldown[source] = nil
        end)
        local query = MySQL.query.await('SELECT * FROM vip_codes WHERE code = ?', { code })
        if #query > 0 then
            if tiers[query[1].tier].Index > players[source].Index then
                MySQL.query.await('DELETE FROM vip_codes WHERE code = ?', { code })
                local tier = tiers[query[1].tier]
                TriggerClientEvent('core:showNotification', source, string.format('Úspěšně si aktivoval %s členství!', tier.Label), 'success')
                MySQL.insert.await('INSERT INTO vip_tiers (identifier, tier, expire) VALUES (?, ?, ?)', { GetIdentifier(source, 'license'), query[1].tier, os.time() + 2592000 })
                checked[source] = nil
                TriggerClientEvent('core:tierUpdated', source)
                local xPlayer = ESX.GetPlayerFromId(source)
                Wait(3000)
                for k,v in ipairs(tier.Instant) do
                    if v.Type == 'item' then
                        xPlayer.addInventoryItem(v.Name, v.Count)
                    elseif v.Type == 'account' then
                        xPlayer.addAccountMoney(v.Name, v.Count)
                    elseif v.Type == 'vehicle' then
                        local plate = exports['av_dealership']:generatePlate()
                        local props = lib.callback.await('core:vehicle', source, v.Hash)
                        props.plate = plate
                        MySQL.insert.await('INSERT INTO owned_vehicles (owner, plate, vehicle, stored) VALUES (?, ?, ?, 1)', { xPlayer.identifier, plate, json.encode(props) })
                        TriggerClientEvent('core:showNotification', source, string.format('Obdržel jsi vozidlo %s.', v.Label), 'success')
                    end
                end
            else
                TriggerClientEvent('core:showNotification', source, 'Už máš aktivované vyšší členství!', 'error')
            end
        else
            TriggerClientEvent('core:showNotification', source, 'Neplatný kód.', 'error')
        end
    else
        TriggerClientEvent('core:showNotification', source, 'Chvíli počkej.', 'error')
    end
end)

lib.callback.register('core:getTier', function(source)
    if checked[source] == nil then
        checked[source] = true
        local license = GetIdentifier(source, 'license')
        local query = MySQL.query.await('SELECT * FROM vip_tiers WHERE identifier = ?', { license })
        if #query > 0 then
            local time = os.time()
            if tonumber(query[1].expire) < time then
                MySQL.query.await('DELETE FROM vip_tiers WHERE identifier = ?', { license })
                players[source] = tiers['none']
                return tiers['none']
            end
            players[source] = tiers[query[1].tier]
            return tiers[query[1].tier], os.date("%x", query[1].expire), (query[1].expire - time) / 2592000 * 100
        else
            players[source] = tiers['none']
            return tiers['none']
        end
    end
end)

local lastDaily = {}

MySQL.ready(function()
    MySQL.query('SELECT * FROM users', {}, function(result)
        for k,v in ipairs(result) do
            lastDaily[v.identifier] = v.lastDaily
        end
    end)
end)

RegisterCommand('daily', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    local last = lastDaily[xPlayer.getIdentifier()]
    if last == nil or last < os.time() then
        lib.callback('core:daily', source, function(success)
            if success then
                lastDaily[xPlayer.getIdentifier()] = os.time() + 86400
                local reward = players[source].Daily[math.random(1, GetTableSize(players[source].Daily))]
                if reward.Type == 'item' then
                    xPlayer.addInventoryItem(reward.Name, reward.Count)
                elseif reward.Type == 'account' then
                    xPlayer.addAccountMoney(reward.Name, reward.Count)
                elseif reward.Type == 'vehicle' then
                    local plate = exports['av_dealership']:generatePlate()
                    local props = lib.callback.await('core:vehicle', v.Hash)
                    props.plate = plate
                    MySQL.insert.await('INSERT INTO owned_vehicles (owner, plate, vehicle) VALUES (?, ?, ?)', { xPlayer.identifier, plate, json.encode(props) })
                    TriggerClientEvent('core:showNotification', source, string.format('Obdržel jsi vozidlo %s.', v.Label), 'success')
                end
                MySQL.update.await('UPDATE users SET lastDaily = ? WHERE identifier = ?', { os.time() + 86400, xPlayer.getIdentifier() })
            end
        end)
    else
        TriggerClientEvent('core:showNotification', source, 'Neuplynulo 24h od vyzvednutí minulé odměny.', 'error')
    end
end)

exports('getPlayerVar', function(id, name)
    return players[id][name]
end)
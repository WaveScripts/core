function ShowNotification(message, messageType)
    lib.notify({
        description = message,
        type = messageType
    })
end

RegisterNetEvent('core:showNotification')
AddEventHandler('core:showNotification', ShowNotification)

local tier = nil
local expire = nil
local percentage = nil

Citizen.CreateThread(function()
    lib.callback('core:getTier', 0, function(currentTier, currentExpire, currentPercentage)
        tier = currentTier
        expire = currentExpire
        percentage = currentPercentage
    end)
end)

RegisterNetEvent('core:tierUpdated')
AddEventHandler('core:tierUpdated', function()
    lib.callback('core:getTier', 0, function(currentTier, currentExpire, currentPercentage)
        tier = currentTier
        expire = currentExpire
        percentage = currentPercentage
    end)
end)

exports('getVar', function(name)
    return tier[name]
end)

RegisterCommand('info', function()
    local playerData = ESX.GetPlayerData()
    local coins
    for k,v in ipairs(playerData.accounts) do
        if v.name == 'if_coin' then -- if coin = infinity coin
            coins = v.money
        end
    end
    lib.registerContext({
        id = 'core_info',
        title = 'Informace',
        options = {
            {
                title = 'Jméno a příjmení',
                description = playerData.firstName .. ' ' .. playerData.lastName,
                icon = 'fa-solid fa-user'
            },
            {
                title = 'Datum narození',
                description = playerData.dateofbirth,
                icon = 'fa-solid fa-calendar'
            },
            {
                title = 'Výška',
                description = tostring(playerData.height),
                icon = 'fa-solid fa-arrows-up-down'
            },
            {
                title = 'Práce',
                description = playerData.job.label .. ' - ' .. playerData.job.grade_label,
                icon = 'fa-solid fa-briefcase'
            },
            {
                title = 'IF-Coin',
                description = 'Zůstatek: ' .. coins,
                icon = 'fa-solid fa-coins'
            },
            {
                title = 'VIP členství',
                description = expire ~= nil and (tier.Label .. ' - Vyprší ' .. expire) or tier.Label,
                icon = 'fa-solid fa-star',
                progress = percentage,
                colorScheme = 'gray'
            },
        },
    })
    lib.showContext('core_info')
end)

lib.callback.register('core:daily', function(source)
    return lib.alertDialog({
        header = 'Vítej zpět na Infinity Roleplay!',
        content = 'Denní odměnu vyzvedneš stisknutím tlačítka "potvrdit".',
        centered = true,
        cancel = true
    }) == 'confirm'
end)

lib.callback.register('core:vehicle', function(hash)
    local veh = nil
    ESX.Game.SpawnVehicle(hash, vector3(0, 0, 10.0), 0, function(vehicle) 
        veh = vehicle
        
    end)
    while veh == nil do
        Wait(100)
    end
    local props = ESX.Game.GetVehicleProperties(veh)
    return props
end)